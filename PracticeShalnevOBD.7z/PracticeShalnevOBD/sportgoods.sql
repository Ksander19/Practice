-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 02 2021 г., 19:12
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `sportgoods`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8 NOT NULL,
  `price` int(11) NOT NULL,
  `weight` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `type`, `price`, `weight`) VALUES
(1, 'JumpStick', 'Jumping equipment', 150, 6),
(2, 'sneakers', 'Running equipment', 290, 2),
(3, 'Flooring', 'Gymnastics equipment ', 30, 1.5),
(4, 'Vault', 'Gymnastics equipment ', 300, 55.2),
(5, 'waterskis', 'Water sports equipment', 80, 2),
(6, 'discus', 'Throwing equipment', 25, 5.5),
(7, 'dumbbell', 'Weightlifting equipment', 12, 10),
(8, 'sword', 'Equipment for sports duels', 130, 1.8),
(9, 'headgear', 'Wrestling equipment', 34, 1.4),
(10, 'speed bag', 'Boxing equipment', 99, 35.5),
(11, 'foil', 'Fencing equipment', 180, 1.7);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `loginUser` varchar(50) CHARACTER SET utf8 NOT NULL,
  `goodName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateOrder` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `loginUser`, `goodName`, `dateOrder`) VALUES
(8, 'alexander', 'waterskis', '2021-05-25 15:39:05'),
(9, 'alexander', 'dumbbell', '2021-06-02 15:39:15'),
(10, 'alexander', 'sneakers', '2021-06-02 18:52:21'),
(11, 'alexander', 'discus', '2021-06-02 18:55:07');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) CHARACTER SET utf8 NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 NOT NULL,
  `phoneNumber` varchar(10) CHARACTER SET utf8 NOT NULL,
  `mail` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `phoneNumber`, `mail`) VALUES
(1, 'alex', '9082231', '0950654235', 'opopqle.official@gmail.com'),
(4, 'alexander', '987654321', '0976654136', 'visage903@gmail.com'),
(5, '1111', 'pцйуйу113', '0235689789', 'qpop@gmail.com');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nameUniq` (`name`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `key1` (`loginUser`),
  ADD KEY `key2` (`goodName`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `loginUniq` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `key1` FOREIGN KEY (`loginUser`) REFERENCES `users` (`login`),
  ADD CONSTRAINT `key2` FOREIGN KEY (`goodName`) REFERENCES `goods` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
