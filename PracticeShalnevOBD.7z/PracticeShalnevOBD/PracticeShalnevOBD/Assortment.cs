﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticeShalnevOBD
{
    public partial class Assortment : Form
    {
        private string loginUser = null;
        private string passwordUser = null;
        private string phoneNumber = null;
        private string mailUser = null;
        private List<SportGood> goods;
        private List<SportGood> searchGoods;
        public String _id, _name, _type, _price, _weight;

        public Assortment()
        {
            InitializeComponent();
        }

        public Assortment(string login, string password, string phone, string mail)
        {
            InitializeComponent();
            loginUser = login;
            passwordUser = password;
            phoneNumber = phone;
            mailUser = mail;
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Main menu = new Main(loginUser, passwordUser, phoneNumber, mailUser);
            menu.Show();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        Point lastPoint;
        private void cap_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void cap_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void getAssortment()
        {
            ConnectionDB database = new ConnectionDB();
            MySqlDataReader reader = null;

            MySqlCommand command = new MySqlCommand("SELECT * FROM `goods`", database.GetConnection());

            try
            {
                database.openConnection();
                reader = command.ExecuteReader();
                goods = new List<SportGood>();
                SportGood c;
                while (reader.Read())
                {
                    string id = reader["id"].ToString();
                    string name = reader["name"].ToString();
                    string type = reader["type"].ToString();
                    string price = reader["price"].ToString();
                    string weight = reader["weight"].ToString();
                    c = new SportGood(id, name, type, price, weight);
                    goods.Add(c);

                    string[] row = { c.Id, c.Name, c.Type, c.Price, c.Weight };
                    goodsGrid.Rows.Add(row);
                }
                reader.Close();
                database.closeConnection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Assortment_Load(object sender, EventArgs e)
        {
            getAssortment();
        }

        private void searchGood()
        {
            String query = $"SELECT * FROM `goods` WHERE ";
            String parametr = "";
            if (searchText.Text != "")
            {
                parametr = $"`name` LIKE '%{searchText.Text}%'";
            }
            if (min.Text != "" || max.Text != "")
            {
                if (min.Text != "" && max.Text == "")
                {
                    if (parametr.Length == 0)
                    {
                        parametr = $"`price` >= {Convert.ToInt32(min.Text)}";
                    }
                    else
                    {
                        parametr += $" AND `price` >= {Convert.ToInt32(min.Text)}";
                    }
                }
                else if (min.Text == "" && max.Text != "")
                {
                    if (parametr.Length == 0)
                    {
                        parametr = $"`price` <= {Convert.ToInt32(max.Text)}";
                    }
                    else
                    {
                        parametr += $" AND `price` <= {Convert.ToInt32(max.Text)}";
                    }
                }
                else if (min.Text != "" && max.Text != "")
                {
                    if (parametr.Length == 0)
                    {
                        parametr = $"`price` BETWEEN {Convert.ToInt32(min.Text)} AND {Convert.ToInt32(max.Text)}";
                    }
                    else
                    {
                        parametr += $" AND `price` BETWEEN {Convert.ToInt32(min.Text)} AND {Convert.ToInt32(max.Text)}";
                    }
                }
            }

            String Types = $"";
            String and = $" AND ";

            if (checkedListType.CheckedItems.Count != 0)
            {

                for (int i = 0; i < checkedListType.CheckedItems.Count; i++)
                {
                    if (i == 0)
                    {
                        Types += $"(`type`=N'{checkedListType.CheckedItems[i]}'";
                    }
                    else
                    {
                        Types += $" OR `type`=N'{checkedListType.CheckedItems[i]}'";
                    }
                }
            }
            if (parametr.Length != 0)
            {
                and += Types;

                if (Types.Length != 0)
                {
                    query += parametr + and + ")";
                }
                else
                {
                    query += parametr;
                }
            }
            else
            {
                query += Types + ")";
            }

            ConnectionDB database = new ConnectionDB();
            MySqlDataReader reader = null;

            MySqlCommand command = new MySqlCommand(query, database.GetConnection());

            try
            {
                database.openConnection();
                reader = command.ExecuteReader();
                searchGoods = new List<SportGood>();
                SportGood c;
                while (reader.Read())
                {
                    string id = reader["id"].ToString();
                    string name = reader["name"].ToString();
                    string type = reader["type"].ToString();
                    string price = reader["price"].ToString();
                    string weight = reader["weight"].ToString();
                    c = new SportGood(id, name, type, price, weight);
                    goods.Add(c);

                    string[] row = { c.Id, c.Name, c.Type, c.Price, c.Weight };
                    goodsGrid.Rows.Add(row);
                }
                reader.Close();
                database.closeConnection();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }



        private void searchButton_Click(object sender, EventArgs e)
        {
            goodsGrid.Rows.Clear();
            searchGood();
        }

        private void goodsGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void clearCheckedList()
        {
            IEnumerator myEnumerator;
            myEnumerator = checkedListType.CheckedIndices.GetEnumerator();
            int y;
            while (myEnumerator.MoveNext() != false)
            {
                y = (int)myEnumerator.Current;
                checkedListType.SetItemChecked(y, false);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            searchText.Clear();
            goodsGrid.Rows.Clear();
            min.Clear();
            max.Clear();
            clearCheckedList();
            foreach (SportGood c in goods)
            {
                string[] row = { c.Id, c.Name, c.Type, c.Price, c.Weight };
                goodsGrid.Rows.Add(row);
            }
        }

        public void getInfo()
        {
            int row = goodsGrid.SelectedCells[0].RowIndex;
            _id = goodsGrid.Rows[row].Cells["id"].Value.ToString();
            _name = goodsGrid.Rows[row].Cells["goodName"].Value.ToString();
            _type = goodsGrid.Rows[row].Cells["type"].Value.ToString();
            _price = goodsGrid.Rows[row].Cells["price"].Value.ToString();
            _weight = goodsGrid.Rows[row].Cells["weight"].Value.ToString();

        }

        private void buyButton_Click(object sender, EventArgs e)
        {
            getInfo();
            ConnectionDB database = new ConnectionDB();
            MySqlDataReader reader = null;

            MySqlCommand command = new MySqlCommand("INSERT INTO `orders` (`loginUser`, `goodName`, `dateOrder`) VALUES(@login, @good, @date)", database.GetConnection());
            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = loginUser;
            command.Parameters.Add("@good", MySqlDbType.VarChar).Value = _name;
            command.Parameters.Add("@date", MySqlDbType.DateTime).Value = DateTime.Now;
            try
            {
                database.openConnection();
                reader = command.ExecuteReader();
                MessageBox.Show("Good was successfully purchased!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                reader.Close();
                database.closeConnection();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

