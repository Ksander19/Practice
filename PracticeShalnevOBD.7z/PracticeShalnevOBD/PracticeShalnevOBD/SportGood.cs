﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PracticeShalnevOBD
{
    class SportGood
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Price { get; set; }
        public string Weight { get; set; }

        public SportGood(string id, string name, string type, string price, string weight)
        {
            Id = id;
            Name = name;
            Type = type;
            Price = price;
            Weight = weight;
        }
    }
}
